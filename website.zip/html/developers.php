<?php
include("database.php");

$db= $connect;
$tableName ="scores";
$columns= ['Username', 'Score', 'Accuracy', 'Combo'];
$fetchData= fetch_data($db, $tableName, $columns);

function fetch_data($db, $tableName, $columns){
	if(empty($db)){
		$msg= "Database connection error";
	}elseif(empty($columns) || !is_array($columns)){
		$msg= "columns Name must be defined in an indexed array";
	}elseif(empty($tableName)){
		$msg= "Table Name is empty";
	}else{

		$columnName= implode(", ", $columns);
		$query= "SELECT ".$columnName." FROM $tableNaame"." ORDER BY Score DESC";
		$result= $db->query($query);

		if($result== true){
			if($result->num_rows > 0) {
				$row=  mysqli_fetch_all($result, MYSQLI_ASSOC);
				$msg= $row;
			} else {
				$msg= "No Data Found";
		}
		}else{
			$msg= msqli_error($db);
		}
	}
	return $msg;
}
function console_log($output, $with_script_tags = true) {
    $js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) .');';
    if ($with_script_tags) {
        $js_code = '<script>' . $js_code . '</script>';
    }
    echo $js_code;
}
?>

