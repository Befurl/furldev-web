# furldev-web
I recently started renting some server space, and so I decided to put a website up on there. This is that website.
