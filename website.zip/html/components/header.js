class Header extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
        this.innerHTML = `
            <header class ="header-outer">
                <div class="header-inner">
                    <div class="header-logo"><a href = "https://www.furldev.com">FURL</a></div>
                    <nav class="header-nav">
                        <a href="https://www.furldev.com">Home</a>
                        <a href="news">News</a>
                        <a href="about">About</a>
                        <a href="projects">Projects</a>
                    </nav>
                </div>
            </header>
        `;
    }
}

customElements.define('header-component', Header);
