<?php
$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "scores";
$connect = new mysqli($hostName, $userName, $password, $databaseName);
if ($connect->connect_error) {
	die("Connection failed: " . $connect->connect_error);
}
?>
